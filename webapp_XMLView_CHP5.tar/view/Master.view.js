sap.ui.jsview("sapui5.demo.mvcapp.view.Master", {
    getControllerName: function () {
        return 'sapui5.demo.mvcapp.controller.Master';
    },
    createContent: function (oController) {
        // TABLE CREATION
        var aColumns = [
            new sap.m.Column({
                header: new sap.m.Text({
                    text: 'ID'
                }),
                footer: new sap.m.Text({
                    text: 'ID'
                })
            }),

            new sap.m.Column({
                header: new sap.m.Text({
                    text: 'Name'
                })
            })
        ];

        // Supplier information
        var oTemplate = new sap.m.ColumnListItem({
            type: "Navigation",
            press: [oController.onListPress, oController],
            cells: [
                new sap.m.ObjectIdentifier({
                    text: '{ID}'
                }),
                new sap.m.ObjectIdentifier({
                    text: '{Name}'
                })
            ]
        });

        // Header- number of suppliers
        var oTableHeader = new sap.m.Toolbar({
            content: [
                new sap.m.Title({
                    text: 'Number of suppliers: {/CountSuppliers}',
                    width: '100%',
                    textAlign: sap.ui.core.TextAlign.Center
                })
            ]
        });

        // The actual table
        var oTable = new sap.m.Table({
            columns: aColumns,
            headerToolbar: oTableHeader
        });

        // We bind the table items to the /Suppliers entries
        oTable.bindItems('/Suppliers', oTemplate);

        // Let's display the table 
        var oPageMaster = new sap.m.Page({
            title: 'Supplier Overview',
            content: [oTable]
        });

        return oPageMaster;
    }
});