sap.ui.define([
	"saptraining/exc/test/unit/controller/App.controller"
], function () {
	"use strict";
});
