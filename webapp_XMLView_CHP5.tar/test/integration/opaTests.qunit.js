/* global QUnit */

sap.ui.require(["sap/training/exc/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
